# Meridian Studio

Sitio web de una página (HTML + CSS + JS, sin build ni dependencias) para el estudio de arquitectura e interiorismo Meridian Studio, Madrid.

## Estructura

```
meridian-studio/
├── index.html      → toda la web (contenido, estilos y comportamiento)
├── .gitignore
└── README.md
```

## Ver la web en local

No hace falta servidor: abre `index.html` directamente en el navegador (doble clic) o arrástralo a una pestaña.

## Subir a GitHub

Si aún no tienes el repositorio creado:

1. Entra en [github.com/new](https://github.com/new) y crea un repositorio (por ejemplo `meridian-studio`). No marques "Add a README" si vas a subir el tuyo propio.
2. Desde la carpeta del proyecto, en la terminal:
   ```
   git init
   git add .
   git commit -m "Primera versión del sitio"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/meridian-studio.git
   git push -u origin main
   ```

Si el repositorio ya existe y solo quieres subir esta versión:
```
git add .
git commit -m "Actualiza el sitio"
git push
```

## Publicar la web gratis con GitHub Pages

Una vez el código está en GitHub:

1. En el repositorio, ve a **Settings → Pages**.
2. En "Source", elige la rama `main` y la carpeta `/ (root)`.
3. Guarda. En uno o dos minutos la web queda publicada en:
   ```
   https://TU_USUARIO.github.io/meridian-studio/
   ```

## Antes de publicar, revisa los datos de contacto

En `index.html`, busca y ajusta si hace falta:

- **Email**: `hola@meridianstudio.es`
- **WhatsApp**: enlace a `wa.me/34611234567`
- **Teléfono**: `+34 910 234 567`
- **Dirección**: Calle Hermosilla, 112, Madrid
- **Instagram**: `@meridian.studio`
- **Proyectos y servicios**: en las secciones `#proyectos` y `#servicios`

## Desplegar también en Vercel (opcional)

Este mismo `index.html` funciona igual en Vercel: basta con importar el repositorio de GitHub en [vercel.com/new](https://vercel.com/new) sin configurar *build command* ni *output directory*.
